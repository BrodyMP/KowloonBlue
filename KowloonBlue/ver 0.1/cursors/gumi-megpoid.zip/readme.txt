﻿=== Gumi Megpoid (orange) Cursor Set ===

By: ko ❤ (http://www.rw-designer.com/user/114989) sabah.jannat.n@gmail.com

Download: http://www.rw-designer.com/cursor-set/gumi-megpoid

Author's description:

Vocaloid Gumi in orange! (all animations and images by me)

Sorry to everyone who downloaded the whole set (。_。)

Green ver: http://www.rw-designer.com/cursor-set/gumi-megpoid-green


==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.